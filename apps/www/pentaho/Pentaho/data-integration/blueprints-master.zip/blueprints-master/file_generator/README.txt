This blueprint simply creates a bunch of weblog files for testing.
It demonstrates how you can generate semi-random values in the sense that you can provide the axes values of the various dimensions involved in the random data.
