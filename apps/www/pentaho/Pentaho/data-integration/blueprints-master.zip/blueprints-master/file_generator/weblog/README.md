This folder will contain sample weblog files if you don't specify a parameter value to the generate-queue-files.ktr transformation.
