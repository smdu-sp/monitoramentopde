This is a simple file layout detector.
It uses the internal Kettle API which is also used in the "Get Fields" functionality of the various text file input step dialogs.

Results end up in the tmp/ folder.

Starting point: Metadata detector - main job.kjb


