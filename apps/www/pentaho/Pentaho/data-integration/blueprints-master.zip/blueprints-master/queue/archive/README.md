This folder contains archived, succesfully processed files

