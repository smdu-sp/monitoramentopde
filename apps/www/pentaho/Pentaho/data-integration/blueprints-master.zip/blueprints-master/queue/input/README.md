This folder will receive input files
