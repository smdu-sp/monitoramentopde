During processing, files will be stored here

