The queue folder contains only those files which have been queued

