define(
({
	createLinkTitle: "Svojstva veze",
	insertImageTitle: "Svojstva slike",
	url: "URL:",
	text: "Opis:",
	target: "Cilj:",
	set: "Postavi",
	currentWindow: "Aktivni prozor",
	parentWindow: "Nadređeni prozor",
	topWindow: "Najviši prozor",
	newWindow: "Novi prozor"
})
);
